let welcome = function(name){
   return `Welcome ${name}`;
}

console.log(welcome("Yahoo Baba"));


let welcome = (name) => {
   return `Welcome ${name}`;
}

console.log(welcome("Yahoo Baba"));


let welcome = (name,age) => {
 return `Welcome ${name} ${age}`;
}
	
console.log(welcome("Yahoo Baba", 30));