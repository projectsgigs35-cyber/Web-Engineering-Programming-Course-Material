var element;

//element = document.all;

//element = document.head;

//element = document.title;

//element = document.body;

//element = document.links;

//element = document.links[0];

//element = document.images;

//element = document.forms;

//element = document.doctype;

//element = document.URL;

//element = document.domain;

//element = document.baseURI;

//element = document.getElementById("header");

//element = document.getElementsByClassName("list");

//element = document.getElementsByClassName("list")[0]

//element = document.getElementsByTagName("ul");

element = document.getElementsByTagName("ul")[2]

console.log(element);
